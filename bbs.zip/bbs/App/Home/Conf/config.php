<?php
return array(
	//'配置项'=>'配置值'
	'LAYOUT_ON'=>true,
	'LAYOUT_NAME'=>'moban',
	'SITE_NAME'=>"老司机论坛",
	'AUTH_PATH'=>array(
		'home/jie/add',
		'home/set/index',
		'home/jie/reply'
		)
);